# jbinit
_iOS booter ramdisk creator for checkm8 based jailbreaks_

Tested on iOS 15.1, should work on all iOS 15

Kernelpatches not included, make sure to bring your own ;P
